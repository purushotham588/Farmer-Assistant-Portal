package com.example.farmer.controller;

import com.example.farmer.model.Payment;
import com.example.farmer.service.impl.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;

@RestController
@CrossOrigin("*")
@RequestMapping("/payment")
public class PaymentController
{
    @Autowired
    private PaymentService paymentService;

    @PostMapping
    public ResponseEntity<?> addPayments(@RequestBody Payment payment)
    {
        HashMap<String, String> res = new HashMap<>();
        try
        {
            paymentService.addPayment(payment);
            return new ResponseEntity<>("Transaction Successful", HttpStatus.OK);
        }
        catch(Exception e)
        {
            res.put("msg", "Transaction Failed"+e.getMessage());
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping
    private ResponseEntity<?> getAllPayments()
    {
        try
        {
            return new ResponseEntity<>(paymentService.getAllPayments(), HttpStatus.OK);
        }
        catch(Exception e)
        {
            return new ResponseEntity<>("Internal Server Error", HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/{id}")
    private ResponseEntity<?> getPaymentsById(@PathVariable String id)
    {
        HashMap<String, String> res = new HashMap<>();
        try
        {
            return new ResponseEntity<>(paymentService.getPaymentsById(id), HttpStatus.OK);
        }
        catch(Exception e)
        {
            res.put("msg:","payments details not found for the provided id"+id);
            return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping
    private ResponseEntity<?> updatePayments(@RequestBody Payment payment)
    {
        HashMap<String, String> res = new HashMap<>();
        try
        {
            return new ResponseEntity<>(paymentService.updatePayment(payment), HttpStatus.OK);
        }
        catch(Exception e)
        {
            res.put("msg:","payments details not updated");
            return new ResponseEntity<>(res, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/{id}")
    private ResponseEntity<?> deletePaymentsById(@PathVariable String id)
    {
        HashMap<String, String> res = new HashMap<>();
        try
        {
            paymentService.deletePaymentById(id);
            res.put("msg:","Payment details deleted successfully");
            return new ResponseEntity<>(res, HttpStatus.OK);
        }
        catch(Exception e)
        {
            res.put("msg:","payments details not found for the provided id"+id+"for deleting");
            return new ResponseEntity<>(res, HttpStatus.NOT_FOUND);
        }
    }


}
