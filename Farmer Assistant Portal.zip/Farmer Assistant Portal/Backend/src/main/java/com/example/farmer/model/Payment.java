package com.example.farmer.model;

import lombok.*;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
@AllArgsConstructor
@NoArgsConstructor
@Data
@ToString
public class Payment
{
    @Id
    private String _id;
    private Long cardNumber;
    private String expiryDate;
    private Integer cvv;
    private String cardHolderName;
    private String totalAmount;
}
