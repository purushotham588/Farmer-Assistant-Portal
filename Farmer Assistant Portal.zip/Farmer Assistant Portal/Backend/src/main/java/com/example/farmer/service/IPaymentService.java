package com.example.farmer.service;

import com.example.farmer.model.Payment;

import java.util.List;

public interface IPaymentService
{
    Payment addPayment(Payment payment);

    List<Payment> getAllPayments();

    Payment getPaymentsById(String id);

    Payment updatePayment(Payment payment);

    void deletePaymentById(String id);
}
