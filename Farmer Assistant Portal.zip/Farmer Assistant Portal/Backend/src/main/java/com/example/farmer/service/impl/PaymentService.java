package com.example.farmer.service.impl;

import com.example.farmer.model.Payment;
import com.example.farmer.repository.IPaymentRepository;
import com.example.farmer.service.IPaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PaymentService implements IPaymentService
{
    @Autowired
    private IPaymentRepository paymentRepository;

    @Override
    public Payment addPayment(Payment payment) {
        return paymentRepository.save(payment);
    }

    @Override
    public List<Payment> getAllPayments() {
        return paymentRepository.findAll();
    }

    @Override
    public Payment getPaymentsById(String id) {
        return paymentRepository.findById(id).get();
    }

    @Override
    public Payment updatePayment(Payment payment) {
        return paymentRepository.save(payment);
    }

    @Override
    public void deletePaymentById(String id) {
        paymentRepository.deleteById(id);
    }
}
