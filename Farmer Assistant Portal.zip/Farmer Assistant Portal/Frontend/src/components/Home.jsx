import React from 'react'
import MainNav from '../Navbar/MainNav';

const Home = () => {
  return (
    <div>
        <MainNav/>
    </div>
  )
}

export default Home;