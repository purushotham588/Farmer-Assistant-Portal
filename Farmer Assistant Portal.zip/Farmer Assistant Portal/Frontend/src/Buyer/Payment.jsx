import axios from "axios";
import React, { useState } from "react";
import { ToastContainer, toast } from "react-toastify";
import BuyerNav from "../Navbar/BuyerNav";
import {useForm} from "react-hook-form"
const Payment = ({ paymentData }) => {
  const [data, setData] = useState()
    const addForm=useForm();
    const{errors}=addForm.formState;
  
    const handleSubmitFunction = async (formData) => {
      try {
        const response = await axios.post("http://localhost:8080/payment", formData);
        setData(response.data);
        toast.success("Order successful!");
        addForm.reset();
      } catch (e) {
        console.error(e);
        toast.error("Payment failed!");
      }
    };
    
    const handleSubmit = addForm.handleSubmit(handleSubmitFunction);
    
  
  // const cardValidate = () => {
  //   if(data.cardNum.length!==12){
  //     alert("enter valid details")
  //     console.log(data.cardNum.length)
  //   }

    
 
  return (
    <div>
      <BuyerNav />
      <div className="grid grid-cols-12 mt-5">
        <div className="col-start-2 col-end-7 mt-5">
          <div className="bg-gray-100 rounded-lg p-8 bg-gradient-to-l from-sky-600  to-green-600 md:ml-auto w-auto mt-10 md:mt-0">
            <h2 className="text-gray-900 text-lg font-medium title-font mb-5">
              Card Payment
            </h2>
            <div className=" ">
              
              <div className=" md:w-1/2 mb-4">
                <label
                  htmlFor="cardNumber"
                  className="leading-7 text-sm text-gray-600"
                >
                  Card Number
                </label>
                <input
                 {...addForm.register("cardNumber", {required:"Required",
                 minLength: {
                  value: 12,
                        message: "minimum 12 digits required",
                      },
                      maxLength: {
                        value: 16,
                              message: " Maximum 16 digits allowed",
                            }
                    }
                 )}
                
                  type="number"
                  id="cardNumber"
                  name="cardNumber"
                  className="w-full bg-white rounded border border-gray-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out"
                />
                <p style={{ color: 'red' }}>{errors.cardNumber&&errors.cardNumber.message}</p>
              </div>
              <div className=" md:w-1/2  mb-4">
                <label htmlFor="cardHolderName" className="leading-7 text-sm text-gray-600">
                  Card Holder Name
                </label>
                <input
                {...addForm.register("cardHolderName", {required:"Name Required"})}
                  type="text"
                  id="cardHolderName"
                  name="cardHolderName"
                  className="w-full bg-white rounded border border-gray-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out"
                />
                <p style={{ color: 'red' }}>{errors.cardHolderName&&errors.cardHolderName.message}</p>
              </div>
            </div>
            <div className=" flex gap-3">
              <div className=" md:w-1/2  mb-4">
                <label htmlFor="cvv" className="leading-7 text-sm text-gray-600">
                  CVV
                </label>
                <input
                 {...addForm.register("cvv", {required:"Required",
                 maxLength: {
                  value: 3,
                        message: " Maximum 3 digits allowed",
                      }
                      
                })}
                  type="number"
                  readOnly={addForm.watch("cvv") && addForm.watch("cvv").length === 3}
                  id="cvv"
                  name="cvv"
                  className="w-full bg-white rounded border border-gray-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out"
                />
                <p style={{ color: 'red' }}>{errors.cvv&&errors.cvv.message}</p>
              </div>
              
            </div>
            <div className=" md:w-1/2 mb-4">
                <label
                  htmlFor="expiryDate"
                  className="leading-7 text-sm text-gray-600"
                >
                  Expiry Date
                </label>
                <input
                 {...addForm.register("expiryDate", {required:"Required",
                 validate: {
                  futureDate: (value) => {
                    const currentDate = new Date();
                    const selectedDate = new Date(value);
                    return selectedDate >= currentDate || "Card is expired";
                  },
                },
                }
                 )}
                  type="Date"
                  id="expiryDate"
                  name="expiryDate"
                  className="w-full bg-white rounded border border-gray-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out"
                />
                <p style={{ color: 'red' }}>{errors.expiryDate&&errors.expiryDate.message}</p>
              </div>
              <div className=" md:w-1/2  mb-4">
                <label htmlFor="name" className="leading-7 text-sm text-gray-600">
                  Amount
                </label>
                <input 
                // value={paymentData.amount}
                {...addForm.register("totalAmount", {required:" Required"})}
                  type="number"
                  id="totalAmount"
                  name="totalAmount"
                  
                  className="w-full bg-white rounded border border-gray-300 focus:border-indigo-500 focus:ring-2 focus:ring-indigo-200 text-base outline-none text-gray-700 py-1 px-3 leading-8 transition-colors duration-200 ease-in-out"
                />
                <p style={{ color: 'red' }}>{errors.totalAmount&&errors.totalAmount.message}</p>
              </div>
            <button
              onClick={handleSubmit}
              className="text-white bg-indigo-500 border-0 py-2 bg-gradient-to-l from-sky-600  to-green-600 px-8 focus:outline-none hover:bg-indigo-600 rounded text-lg"
            >
              MakePayment
            </button>
          </div>
        </div>
      </div>
      <ToastContainer/>
    </div>
  );
};

export default Payment;
